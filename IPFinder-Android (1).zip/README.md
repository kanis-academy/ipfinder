# IP Finder (Android)

1. Créez un dépôt GitHub et envoyez tous ces fichiers (dossier `.github` compris).
2. Onglet Actions > « Build APK » > Run workflow.
3. Téléchargez l’artefact `IPFinder-APK`, dézippez, installez `app-debug.apk`.
4. Dans l’app : activez le service d’accessibilité « IP Finder », désactivez le Wi-Fi (données mobiles), choisissez votre VPN, lancez.
